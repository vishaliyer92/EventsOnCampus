<?php




$con = mysqli_connect("localhost","root","","eoc");
/*if (!$con)
  {
  die('Could not connect: ' . mysql_error());
  }

mysql_select_db("eoc", $con); */
?>